package DeliveryModule.BusinessLayer.Test;

public interface Testable
{
    void ExecTest();
}
